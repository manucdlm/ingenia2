package org.ingenia.comunes.excepcion;

public class AdaptadorException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8405248572407537651L;

}
